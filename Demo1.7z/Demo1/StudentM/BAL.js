var DAL=require("../StudentM/DAL")

// Delete Student by Id
exports.DeleteStudent = function (req, res, callback) {
    DAL.DeleteStudent(req, function (data, err) {
        callback(data);
    });

}

// Add New Student 
exports.SaveStudent = function (req, res, callback) {
    DAL.SaveStudent(req, function (data, err) {
        callback(data);
    });

}

//Get All Student List
exports.GetStudent = function (req, res, callback) {
    DAL.GetStudent(req, function (data, err) {
        callback(data);
    });
}

//Get Student by Id 
exports.GetStudentDetails = function (req, res, callback) {
    DAL.GetStudentDetails(req, function (data, err) {
        callback(data);
    });


}