const { json } = require('express');
var Connection = require('tedious').Connection,
    Request = require('tedious').Request,
    TYPES = require('tedious').TYPES;

var Config=require("../Common/Config")

// Delete Student By Id
exports.DeleteStudent = function (req,callback) {   
    var connection = new Connection(Config.connectionString);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });   
        request.addParameter('commandType', TYPES.VarChar, "D");
        request.addParameter('StudentId', TYPES.Int,req.body.StudentId);
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            callback(JSON.stringify(paramName + ' : ' + value));
        });
       
    });
}

//Add New Student in Db
exports.SaveStudent = function (req,callback) {   
    var connection = new Connection(Config.connectionString);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            }); 
        request.addParameter('StudentId', TYPES.Int, req.body.StudentId);
        request.addParameter('FirstName', TYPES.VarChar, req.body.FirstName);
        request.addParameter('LastName', TYPES.VarChar, req.body.LastName);
        request.addParameter('EmailId', TYPES.VarChar, req.body.EmailId);
        request.addParameter('Age', TYPES.Int, req.body.Age);
        request.addParameter('commandType', TYPES.VarChar, req.body.CommandType);
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            callback(JSON.stringify(paramName + ' : ' + value));
        });      
    });
}

// Get All Student from Db
exports.GetStudent = function (req,callback) {   
    var connection = new Connection(Config.connectionString);    
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });      

        request.addParameter('commandType', TYPES.VarChar, "Get");
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            console.log(paramName + ' : ' + value);
        });

        var result = "";
        var ArrayLst = new Array();
        request.on('row', function (columns) {
            var obj = new Object();
            columns.forEach(function (column) {
                result += column.value + " ";
                obj[column.metadata.colName] = column.value;
            });
            ArrayLst.push(obj);
            result = "";
        });

        request.on('doneProc', function (rowCount, more, rows) {           
            callback(JSON.stringify(ArrayLst));
        });

        request.on('requestCompleted', function () {           
            var i=10;
        });

       
    });
}

//Get Student by Id
exports.GetStudentDetails = function (req,callback) {   
    var connection = new Connection(Config.connectionString);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });              
        request.addParameter('StudentId', TYPES.Int,req.body.StudentId);
        request.addParameter('commandType', TYPES.VarChar, "Get");        
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            console.log(paramName + ' : ' + value);
        });

        var result = "";
        var ArrayLst = new Array();
        request.on('row', function (columns) {
            var obj = new Object();
            columns.forEach(function (column) {
                result += column.value + " ";
                obj[column.metadata.colName] = column.value;
            });
            ArrayLst.push(obj);
            result = "";
        });

        request.on('doneProc', function (rowCount, more, rows) {          
            callback(JSON.stringify(ArrayLst));
        });

       
    });
}