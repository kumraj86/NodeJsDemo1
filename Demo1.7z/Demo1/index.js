const express = require("express");
const { json } = require("express");
const app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json())

var BAL_Logger = require("../Demo1/LoggerM/BAL");
var BAL_Student = require("../Demo1/StudentM/BAL");
var BAL_Client = require("../Demo1/ClientM/BAL");

// CORS Enabled
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  next();
});

//Request Loggs
let RequestLogger = (req, res, next) => {
  req.logCode = RandomNo(20);
  req.requestTime = new Date();
  BAL_Logger.ReadRequest(req, function (data, err) {
   // res.send(data);
  });
  next();
};

//Ip Validate
let IsValidRequest = (req, res, next) => {
  req.logCode = RandomNo(20);
  req.requestTime = new Date();
  BAL_Logger.IsValidRequest(req, function (data, err) {
    if (!data) {
      res.status(401).send(req.autherror);
    }
  });
  next();
};
app.use(RequestLogger, IsValidRequest);


// Generate Unique Id for each request-response
function RandomNo(length) {
  var result = "";
  var characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

// Response Loggs
app.use(function(req, res, next) {
  var temp = res.send
  res.send = function() {
      res.responseTime=new Date();
      res.resbody=arguments[0];
      res.LogCode=res.req.logCode;
      BAL_Logger.ReadResponse(res,function (data,err) {
        //res.send(data);
      });
      temp.apply(this,arguments);
  }
  next();
})

//Error handling
app.use(function (err, req, res, next) {
  req.errorOccurTime = new Date();
  BAL_Logger.WriteLogs(req, err, function (data, err) {
    // res.send(data);
  });
  res.status(500);
  res.send("Oops, something went wrong.");
});


// Below Mentioned API Methods.
app.post("/student/DeleteStudent", function (req, res) {
  BAL_Student.DeleteStudent(req, res, function (data, err) {
    res.send(data);
  });
});

app.post("/student/SaveStudent", function (req, res) {
  BAL_Student.SaveStudent(req, res, function (data, err) {
    res.send(data);
  });
});

app.get("/student/GetStudent", function (req, res) {
  BAL_Student.GetStudent(req, res, function (data, err) {  
      res.send(data);   
  });
});

app.post("/student/GetStudentDetails", function (req, res) {
  BAL_Student.GetStudentDetails(req, res, function (data, err) {
    res.send(data);
  });
});


// Service Hosting..
const webserver = app.listen(3000, function (req, res) {
  console.log("Service is running mode");
});


