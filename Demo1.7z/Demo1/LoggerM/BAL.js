var DAL=require("../LoggerM/DAL")
var Config=require("../Common/Config")

// Write Request details 
exports.ReadRequest = function (req, callback) {
    DAL.ReadRequest(req, function (data, err) {
        callback(data);
    });
}

// Write Response details
exports.ReadResponse = function (res, callback) {
    DAL.ReadResponse(res, function (data, err) {
        callback(data);
    });
}


// Validate IP request
exports.IsValidRequest = function (req, callback) {
    let ipWhiteList = Config.WhilteListIpAddress;
    let requestStatus = false;
    for (var i = 0; i < ipWhiteList.length; i++) {
        if (req.ip == ipWhiteList[i]) {
            requestStatus = true;
            break;
        }
        requestStatus = false;
    }
    callback(requestStatus);
}


// Write Error Logs 
exports.WriteLogs = function (req, err, callback) {
    DAL.WriteLogs(req, err, function (data, err) {
        callback(data);
    });
}