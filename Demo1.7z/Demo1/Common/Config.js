// database connectiond
exports.connectionString={
    server: 'localhost',
    authentication: {
        type: 'default',
        options: {
            userName: 'sa',
            password: 'admin@123'
        }
    },
    options: {
        encrypt: false,
        database: 'Test'
    }
}

// Ip WhiteLists
exports.WhilteListIpAddress=["127.0.0.1","10.75.19.87","10.16.240.6","::1","::ffff:192.168.29.191"]
